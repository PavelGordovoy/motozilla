<?php

return array(
    'code' => 'DKK',
    'sign' => 'kr.',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Danish krone',
    'name' => array(
        array('krone', 'kroner'),
    ),
    'frac_name' => array(
        'ore',
    )
);