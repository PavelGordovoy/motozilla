<?php

return array(
    'code' => 'GTQ',
    'sign' => 'Q',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Guatemalan quetzal',
    'name' => array(
        array('quetzal', 'quetzals'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);