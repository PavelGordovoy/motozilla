<?php

return array(
    'code' => 'BGN',
    'sign' => 'лв',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Bulgarian lev',
    'name' => array(
        'lev',
    ),
    'frac_name' => array(
        array('stotinka', 'stotinki'),
    )
);