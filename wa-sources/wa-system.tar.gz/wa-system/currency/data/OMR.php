<?php

return array(
    'code' => 'OMR',
    'sign' => 'rial',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Omani rial',
    'name' => array(
        array('rial', 'rials'),
    ),
    'frac_name' => array(
        'baisa',
    )
);