<?php

return array(
    'code' => 'PKR',
    'sign' => 'Rs',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Pakistani rupee',
    'name' => array(
        array('rupee', 'rupees'),
        '₨',
    ),
    'frac_name' => array(
    )
);